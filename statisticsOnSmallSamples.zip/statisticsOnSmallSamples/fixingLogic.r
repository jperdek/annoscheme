#install.packages('dplyr')
#install.packages('bestNormalize')
#install.packages('ggplot2')
#install.packages('easyGgplot2')
#install.packages('devtools')
#install.packages('data.table')
#install.packages('rstatix')
library(dplyr)
library(bestNormalize)
library(devtools)
library(ggplot2)
library(broom)
library(stringr)
library(data.table)

library(rstatix)
devtools::install_github("kassambara/easyGgplot2")
library(easyGgplot2)

setwd("D:/statisticsOnSmallSamples")




formData <<- read.csv('./smallSamplesStatistics.csv', sep=";")

lapply(colnames(formData), function(columnName, data) {
  formData[[columnName]] <<- as.double(unlist(lapply(formData[[columnName]], function(a)  eval(parse(text =str_replace(str_replace(a, ",", "."), ":", " * 60 + "))))))
}, data=formData)

print(formData)


ifPaired <- FALSE
chosenAlternative <- c("two.sided", "less", "greater")
testColumnNames <- c('comparedName', 'correlation', 'statistics W', 'p.value', 'null.value', 'alternative', 'method', 'data.name', 'confidence.interval.start', 'confidence.interval.end', 'estimate')
finalWilcoxTest <<- data.frame(matrix(nrow = 0, ncol = length(testColumnNames)))
colnames(finalWilcoxTest) <- testColumnNames


columnName1a <- "WithAnnonschemeFixingLogic"
columnName1b <- "WithoutAnnonschemeFixingLogic"
columnNameMerged1 <- "FixingLogic"
correlation <- cor(formData[[columnName1a]], formData[[columnName1b]], method = "spearman")
wilcoxTest <- wilcox.test(formData[[columnName1a]], formData[[columnName1b]], alternative=chosenAlternative, paired=ifPaired, exact = TRUE, correct = TRUE,
                          conf.int = TRUE, conf.level = 0.95)
confInt <- as.vector(wilcoxTest$conf.int)
finalWilcoxTest <<- rbind(finalWilcoxTest, c(columnNameMerged1, as.double(correlation), wilcoxTest$statistic,
                                             as.double(wilcoxTest$p.value), as.double(wilcoxTest$null.value), wilcoxTest$alternative, 
                                             wilcoxTest$method, wilcoxTest$data.name, as.double(confInt[1]), as.double(confInt[2]), as.double(wilcoxTest$estimate )))


columnName2a <- "WithAnnonschemePerformingChanges"
columnName2b <- "WithoutAnnonschemePerformingChanges"
columnNameMerged2 <- "PerformingChanges"
correlation <- cor(formData[[columnName2a]], formData[[columnName2b]], method = "spearman")
wilcoxTest <- wilcox.test(formData[[columnName2a]], formData[[columnName2b]], alternative=chosenAlternative, paired=ifPaired, exact = TRUE, correct = TRUE,
                          conf.int = TRUE, conf.level = 0.95)
confInt <- as.vector(wilcoxTest$conf.int)
finalWilcoxTest <<- rbind(finalWilcoxTest, c(columnNameMerged2, as.double(correlation), wilcoxTest$statistic,
                                             as.double(wilcoxTest$p.value), as.double(wilcoxTest$null.value), wilcoxTest$alternative, 
                                             wilcoxTest$method, wilcoxTest$data.name, as.double(confInt[1]), as.double(confInt[2]), as.double(wilcoxTest$estimate )))


columnName3a <- "WithAnnonschemeIdentifySourceConstructsChange"
columnName3b <- "WithoutAnnonschemeSourceConstructsChange"
columnNameMerged3 <- "SourceConstructsChange"
correlation <- cor(formData[[columnName1a]], formData[[columnName3b]], method = "spearman")
wilcoxTest <- wilcox.test(formData[[columnName3a]], formData[[columnName3b]], alternative=chosenAlternative, paired=ifPaired, exact = TRUE, correct = TRUE,
                          conf.int = TRUE, conf.level = 0.95)
confInt <- as.vector(wilcoxTest$conf.int)
finalWilcoxTest <<- rbind(finalWilcoxTest, c(columnNameMerged3, as.double(correlation), wilcoxTest$statistic,
                                             as.double(wilcoxTest$p.value), as.double(wilcoxTest$null.value), wilcoxTest$alternative, 
                                             wilcoxTest$method, wilcoxTest$data.name, as.double(confInt[1]), as.double(confInt[2]), as.double(wilcoxTest$estimate )))


columnName4a <- "WithAnnonschemeUsingRequiredImpl"
columnName4b <- "WithoutAnnonschemeUsingRequiredImpl"
columnNameMerged4 <- "UsingRequiredImpl"
correlation <- cor(formData[[columnName4a]], formData[[columnName4b]], method = "spearman")
wilcoxTest <- wilcox.test(formData[[columnName4a]], formData[[columnName4b]], alternative=chosenAlternative, paired=ifPaired, exact = TRUE, correct = TRUE,
                          conf.int = TRUE, conf.level = 0.95)
confInt <- as.vector(wilcoxTest$conf.int)
finalWilcoxTest <<- rbind(finalWilcoxTest, c(columnNameMerged4, as.double(correlation), wilcoxTest$statistic,
                                             as.double(wilcoxTest$p.value), as.double(wilcoxTest$null.value), wilcoxTest$alternative, 
                                             wilcoxTest$method, wilcoxTest$data.name, as.double(confInt[1]), as.double(confInt[2]), as.double(wilcoxTest$estimate )))



columnName5a <- "WithAnnonschemeFindingRequiredImpl"
columnName5b <- "WithoutAnnonschemeFindingRequiredImpl"
columnNameMerged5 <- "FindingRequiredImpl"
correlation <- cor(formData[[columnName5a]], formData[[columnName5b]], method = "spearman")
wilcoxTest <- wilcox.test(formData[[columnName5a]], formData[[columnName5b]], alternative=chosenAlternative, paired=ifPaired, exact = TRUE, correct = TRUE,
                          conf.int = TRUE, conf.level = 0.95)
confInt <- as.vector(wilcoxTest$conf.int)
finalWilcoxTest <<- rbind(finalWilcoxTest, c(columnNameMerged5, as.double(correlation), wilcoxTest$statistic,
                                             as.double(wilcoxTest$p.value), as.double(wilcoxTest$null.value), wilcoxTest$alternative, 
                                             wilcoxTest$method, wilcoxTest$data.name, as.double(confInt[1]), as.double(confInt[2]), as.double(wilcoxTest$estimate )))



colnames(finalWilcoxTest) <- testColumnNames


write.table(finalWilcoxTest, ".\\fixingLogic.csv", row.names=FALSE, dec=",", sep=";")

