#'# Statistika subor smallSamplesStatistics
#'
#'
#'#'nastavenie adresara
setwd("D:/statisticsOnSmallSamples")
library(readxl)

#' Data som previedla na minuty, lebo sa s tym robi lepsie ako s casovymi udajmi
#' 
#' 
data <- read_xlsx("D:/statisticsOnSmallSamples/mima statistika.xlsx")

sdata <- data[, 2:10]
library(Amelia)
library(Rcpp)
ndata <- na.omit(sdata)
data12 <- data[, 11:12]


# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Testovanie normality 
#'
#'
# Spustíme Shapiro-Wilkov test pre každý numerický stĺpec a uložíme výsledky do dátového rámca
results_df <- do.call(rbind, lapply(names(ndata), function(nazov_stlpca) {
  x <- ndata[[nazov_stlpca]]
  if(is.numeric(x)){
    test_result <- shapiro.test(x)
    p_value <- test_result$p.value
    # Určíme verdikt na základe p-hodnoty
    verdikt <- ifelse(p_value > 0.05, "Normálne rozdelený", "Ne-normálne rozdelený")
    data.frame(
      Stĺpec = nazov_stlpca,
      P_hodnota = p_value,
      Verdikt = verdikt,
      stringsAsFactors = FALSE
    )
  } else {
    # Ak stĺpec nie je numerický, môžeme to zaznamenať
    data.frame(
      Stĺpec = nazov_stlpca,
      P_hodnota = NA,
      Verdikt = "Nie je numerický",
      stringsAsFactors = FALSE
    )
  }
}))

# Výsledná tabuľka
print(results_df)

















# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

#'# Testovanie normality aj s testom 
#' 
results1 <- lapply(ndata, function(x) {
  # Skontrolovať, či je stĺpec numerický
  if(is.numeric(x)) {
    shapiro.test(x)
  } else {
    return(NA)  # alebo iná správa, že stĺpec nie je numerický
  }
})

# Výpis výsledkov
results1

#'
#'
#'
#' Testovanie normality pre stlpe K a L

results2 <- lapply(data12, function(x) {
  # Skontrolovať, či je stĺpec numerický
  if(is.numeric(x)) {
    shapiro.test(x)
  } else {
    return(NA)  # alebo iná správa, že stĺpec nie je numerický
  }
})

# Výpis výsledkov
results2

#'# Normalita graficky
#'
#'
par(mfrow=c(3, 3)) # nastavíme mriežku 3x3 pre viac grafov, uprav podľa počtu stĺpcov

for(i in 1:ncol(ndata)){
  qqnorm(ndata[[i]], main=paste("Q-Q plot pre stĺpec", colnames(ndata)[i]))
  qqline(ndata[[i]], col="red")
}


par(mfrow=c(2, 1)) # nastavíme mriežku 3x3 pre viac grafov, uprav podľa počtu stĺpcov

for(i in 1:ncol(data12)){
  qqnorm(data12[[i]], main=paste("Q-Q plot pre stĺpec", colnames(data12)[i]))
  qqline(data12[[i]], col="red")
}
par(mfrow=c(1, 1))

#' Verdikt: graficky vyzeraju dobre 2., 5., 6., 8.,10.  Pri ostatnych by som bola s 
#' tou normalitou opatrna a radsej ju v clanku nijako zvlast nezvyraznovala, 
#' lebo tych dat je naozaj malo. Ale pri testoch sa budeme tvarit, ze to normalne je.
#' Okrem stlpca E. ten je naozaj nenormalny. Preto som poutila Wilkoxa
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Predpokladám, že máš načítané objekty:
# ndata a data12

# Definujeme dvojice stĺpcov v ndata
pary_stlpcov <- list(
  c(1, 2),
  c(3, 4),
  c(5, 6),
  c(7, 8),
  c(9, 1)  # 9. stĺpec v ndata a prvý v data12 (posledná dvojica)
)

# Vytvoríme prázdnu tabuľku na výsledky
vysledok_tab <- data.frame(
  VektorovaDvojica = character(),
  p_hodnota = numeric(),
  Verdikt = character(),
  stringsAsFactors=FALSE
)

# Porovnanie
for(i in seq_along(pary_stlpcov)){
  pair <- pary_stlpcov[[i]]
  stlpec1 <- pair[1]
  stlpec2 <- pair[2]
  
  # Vyberieme stĺpce z ndata
  x1 <- ndata[[stlpec1]]
  
  # Pre poslednú dvojicu používame z data12
  if(i == length(pary_stlpcov)){
    x2 <- data12[[stlpec2]]
  } else {
    x2 <- ndata[[stlpec2]]
  }
  
  # Vykonáme t-test medzi týmito dvomi stĺpcami
  ttest_res <- var.test(x1, x2)
  
  # P-hodnota
  p_value <- ttest_res$p.value
  
  # Určíme verdikt na základe p-hodnoty
  verdikt <- ifelse(p_value < 0.05, "non-equal", "equal")
  
  # Zapisujeme do tabuľky
  dvojica_str <- paste0("stlpec", stlpec1, " & stlpec", stlpec2)
  vysledok_tab <- rbind(vysledok_tab, data.frame(
    VektorovaDvojica = dvojica_str,
    p_hodnota = p_value,
    Verdikt = verdikt,
    stringsAsFactors=FALSE
  ))
}

# Výsledná tabuľka
print(vysledok_tab)
#'pri dvojichach, v ktorych vysiel test, ze medzi disperziami 
#'nie je statisticky vyzmanmy rozdiel do testov pre porovnanie strednyc hodn;t pridame 
#'parameter r rovnosti. +Standardne je v testoch nastaveny na False.




# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Test 1 Nezávislý test medzi stĺpcami "B" a "C"
t.test(ndata$WithAnnonschemeFixingLogic, ndata$WithoutAnnonschemeFixingLogic)$p.value


values <- list(ndata$WithAnnonschemeFixingLogic, ndata$WithoutAnnonschemeFixingLogic)
names <- c("With AFL", "Without AFL")
# Vytvoriť boxplot
boxplot(values, names=names, main="Boxplot 1",col=c("red","lightblue"),horizontal = TRUE )



# Uloženie obrázka ako JPG
jpeg("boxplot_1.jpg", width=800, height=600)
# Vytvorenie boxplotu
boxplot(values, names=names, main="Boxplot 1",col=c("red","lightblue"),horizontal = TRUE )
# Ukončenie ukladania obrázka
dev.off()
#' Verdikt: test hovori, ze su rozne a vidiet aj na boxplote. Krabice su mimo

# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Test 2 Nezávislý test medzi stĺpcami "D" a "E"
wilcox.test(ndata$WithAnnonschemePerformingChanges, ndata$WithoutAnnonschemePerformingChanges,paired=FALSE)$p.value


values <- list(ndata$WithAnnonschemePerformingChanges, ndata$WithoutAnnonschemePerformingChanges)
names <- c("With APC", "Without APC")
# Vytvoriť boxplot
boxplot(values, names=names, main="Boxplot 2",col=c("red","lightblue"),horizontal = TRUE )



# Uloženie obrázka ako JPG
jpeg("boxplot_2.jpg", width=800, height=600)
# Vytvorenie boxplotu
boxplot(values, names=names, main="Boxplot 2",col=c("red","lightblue"),horizontal = TRUE )
# Ukončenie ukladania obrázka
dev.off()
#' Verdikt:test hovori, ze medzi nimi nie je rozdiel, ale krabice su mimo. 
#' Na zaklade toho, ze je tych dat malo s 5% chybou mozem povedat, 
#' ze nie je medzi nimi rozdiel. Krabice su take preto, ze su tam odjahle data, 
#' ktore tie boxploty deformuju.


# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Test 3 Nezávislý test medzi stĺpcami "F" a "G"
t.test(ndata$WithAnnonschemeIdentifySourceConstructsChange, 
                  ndata$WithoutAnnonschemeSourceConstructsChange, 
                  var.equal = TRUE)$p.value



values <- list(ndata$WithAnnonschemeIdentifySourceConstructsChange
               , ndata$WithoutAnnonschemeSourceConstructsChange)
names <- c("With AIS", "Without AIS")
# Vytvoriť boxplot
boxplot(values, names=names, main="Boxplot 3",col=c("red","lightblue"),horizontal = TRUE )



# Uloženie obrázka ako JPG
jpeg("boxplot_3.jpg", width=800, height=600)
# Vytvorenie boxplotu
boxplot(values, names=names, main="Boxplot 3",col=c("red","lightblue"),horizontal = TRUE )
# Ukončenie ukladania obrázka
dev.off()

#' Verdikt: test hovori,ze nie je medzi nimi rozdie a boxplot tomu neodporuje.


# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Test 4 Nezávislý test medzi stĺpcami "H" a "I"
t.test(ndata$WithAnnonschemeUsingRequiredImpl, ndata$WithoutAnnonschemeUsingRequiredImpl)$p.value



values <- list(ndata$WithAnnonschemeUsingRequiredImpl, ndata$WithoutAnnonschemeUsingRequiredImpl)
names <- c("With ARI", "Without ARI")
# Vytvoriť boxplot
boxplot(values, names=names, main="Boxplot 4",col=c("red","lightblue"),horizontal = TRUE )



# Uloženie obrázka ako JPG
jpeg("boxplot_4.jpg", width=800, height=600)
# Vytvorenie boxplotu
boxplot(values, names=names, main="Boxplot 4",col=c("red","lightblue"),horizontal = TRUE )
# Ukončenie ukladania obrázka
dev.off()

#' Verdikt: test hovori, 6e su rozdielne a vidiet aj na boxplote. Krabice su mimo


# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'# Test 5 Nezávislý test medzi stĺpcami "J" a "K" lebo maju roznu dlzku
t.test(ndata$WithAnnonschemeFindingRequiredImpl, data12$WithoutAnnonschemeFindingRequiredImpl,var.equal = TRUE)$p.value


values <- list(ndata$WithAnnonschemeFindingRequiredImpl, data12$WithoutAnnonschemeFindingRequiredImpl)
names <- c("With AIS", "Without AIS")
# Vytvoriť boxplot
boxplot(values, names=names, main="Boxplot 5",col=c("red","lightblue"),horizontal = TRUE )



# Uloženie obrázka ako JPG
jpeg("boxplot_5.jpg", width=800, height=600)
# Vytvorenie boxplotu
boxplot(values, names=names, main="Boxplot 5",col=c("red","lightblue"),horizontal = TRUE )
# Ukončenie ukladania obrázka
dev.off()

#' Verdikt: test hovori,ze nie je medzi nimi rozdie a boxplot tomu neodporuje.

# xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


#' Histogramy 
#' 
#' 
#' Pre pre stlpce B az J
#' 

# Nastavíme rozloženie grafov
par(mfrow=c(3,3))

for(nazov_stlpca in names(ndata)){
  x <- ndata[[nazov_stlpca]]
  if(is.numeric(x)){
    # Vytvoríme histogram bez grafických prvkov
    hist_obj <- hist(x, breaks=6, plot=FALSE)
    # Vykreslíme histogram
    hist(x, breaks=6, main=paste("Histogram pre", nazov_stlpca), xlab=nazov_stlpca, col="lightgray", freq=FALSE)
    
    # Priemerná hodnota a smerodajná odchýlka
    mu <- mean(x, na.rm=TRUE)
    sigma <- sd(x, na.rm=TRUE)
    
    # Pridáme krivku normálneho rozdelenia
    curve(dnorm(x, mean=mu, sd=sigma), add=TRUE, col="blue", lwd=2)
  }
}

par(mfrow=c(1,1))

#'Histogram pre stlpec K
#'
#'
hist(data12$WithoutAnnonschemeFindingRequiredImpl, breaks=10, main=paste("Histogram pre WithoutAnnonschemeFindingRequiredImpl"), xlab="WithoutAnnonschemeFindingRequiredImpl", freq=FALSE)
# Vypočítame parametre normálneho rozdelenia
mu <- mean(data12$WithoutAnnonschemeFindingRequiredImpl, na.rm=TRUE)
sigma <- sd(data12$WithoutAnnonschemeFindingRequiredImpl, na.rm=TRUE)
# Zakreslíme krivku normálneho rozdelenia
curve(dnorm(x, mean=mu, sd=sigma), add=TRUE, col="blue", lwd=2)



#'# Finalne hodnotenie
#'
#' Dat je velmi malo, vysledky by sa dali brat ako pilotna studia a 
#' do buducna treba na silu testu beta=0.9 pri alfe=0.5 minimalne 15 
#' hodnot vo vektore 
#' 
#' 
#'# Statistiky pre vypocet beta
#' 
#' Vytvoríme dátový rámec s názvom stĺpca, mean a sd
tabulka <- data.frame(
  Nazov_stlpca = character(),
  Mean = numeric(),
  SD = numeric(),
  stringsAsFactors = FALSE
)

#' Pre každý stĺpec v dátovom rámci
for(nazov_stlpca in names(ndata)){
  x <- ndata[[nazov_stlpca]]
  # Ak je stĺpec numerický
  if(is.numeric(x)){
    # Vypočítame priemer a štandardnú odchýlku
    mean_value <- mean(x, na.rm=TRUE)
    sd_value <- sd(x, na.rm=TRUE)
    # Pridáme riadok do tabuľky
    novy_riadok <- data.frame(
      Nazov_stlpca = nazov_stlpca,
      Mean = mean_value,
      SD = sd_value,
      stringsAsFactors = FALSE
    )
    tabulka <- rbind(tabulka, novy_riadok)
  }
}

#' Zobrazíme tabuľku
print(tabulka)


mean(data12$WithoutAnnonschemeFindingRequiredImpl)
sd(data12$WithoutAnnonschemeFindingRequiredImpl)

#'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#'
#'# Vypocet sily testu a potrebneho poctu dat vo vzorke

library(pwr)

# Definuj dvojice priamo ako vektorov
pary_stlpcov <- list(
  c(ndata[,1], ndata[,2]),
  c(ndata[,3], ndata[,4]),
  c(ndata[,5], ndata[,6]),
  c(ndata[,7], ndata[,8]),
  c(ndata[,9], data12[,1])
)

for (i in seq_along(pary_stlpcov)) {
  cat("Dvojica č.", i, ":\n")
  print(pary_stlpcov[[i]][1]) # Vypíše prvý vektor
  cat("\n")
  print(pary_stlpcov[[i]][2]) # Vypíše druhý vektor
  cat("\n-----------------\n")
}

alfa <- 0.05
cilova_sila <- 0.9

# Funkcia na výpočet Cohen's d medzi dvoma vektormi
compute_effect_size <- function(vec1, vec2) {
  mean1 <- mean(vec1)
  mean2 <- mean(vec2)
  sd1 <- sd(vec1)
  sd2 <- sd(vec2)
  n1 <- length(vec1)
  n2 <- length(vec2)
  sd_pooled <- sqrt(((n1 - 1)*sd1^2 + (n2 - 1)*sd2^2) / (n1 + n2 - 2))
  d <- abs(mean1 - mean2) / sd_pooled
  return(d)
}

# Funkcia na výpočet sily testu pre daný n a efektovú veľkosť
compute_power <- function(n1, n2, d, alpha=0.05) {
  result <- pwr.t.test(n = n1, d = d, sig.level = alpha, type = "two.sample", alternative = "two.sided")
  return(result$power)
}

# Spracovanie pevne zadaných dvojíc
spracovane_pary <- list()

for (pair in pary_stlpcov) {
  vec1 <- pair[[1]]
  vec2 <- pair[[2]]
  
  # Nájdeme spoločné indexy podľa dĺžky
  len1 <- length(vec1)
  len2 <- length(vec2)
  len_min <- min(len1, len2)
  
  vec1_shared <- vec1[1:len_min]
  vec2_shared <- vec2[1:len_min]
  
  # Vypočítame efektovú veľkosť
  effect_size <- compute_effect_size(vec1_shared, vec2_shared)
  
  n1 <- length(vec1_shared)
  n2 <- length(vec2_shared)
  
  # Aktuálna sila testu
  current_power <- compute_power(n1, n2, effect_size, alfa)
  
  cat("Pár stĺpcov:\n")
  cat("  Dĺžka skupiny:", n1, "\n")
  cat("  Efektová veľkosť (d):", round(effect_size, 3), "\n")
  cat("  Aktuálna sila testu:", round(current_power, 3), "\n")
  
  # Výpočet potrebného počtu vo vektoroch na silu 0,9
  needed_n <- pwr.t.test(d = effect_size, power = cilova_sila, sig.level = alfa, type = "two.sample", alternative = "two.sided")$n
  needed_n_celek <- ceiling(needed_n)
  
  cat("  Potrebný počet v každej skupine pre silu 0,9:", needed_n_celek, "\n\n")
 
}

#'# Poznamky

#' Efektová veľkosť Cohen's d je štatistická miera, ktorá vyjadruje veľkosť 
#' rozdielu medzi dvoma skupinami v jednotkách štandardnej odchýlky. 
#' Je to štandardizovaný rozdiel medzi priemermi dvoch skupín, ktorý 
#' umožňuje porovnávať veľkosti efektov naprieč rôznymi štúdiami alebo meraniami.
#' 
#'Interpretácia Cohenovho d:

#' 0.2 = malý efekt
#' 0.5 = stredný efekt
#' 0.8 a viac = veľký efekt

#' Tedanapríklad d = 2.363 je extrémne veľký efekt, čo naznačuje, 
#' že rozdiel medzi skupinami je výrazný a pravdepodobne veľmi významný. 
#' 
#' 
#' 
#' Sila testu (anglicky statistical power) je pravdepodobnosť, že štatistický test 
#' správne odhalí existenciu skutočného efektu alebo rozdielu, keď tento efekt 
#' naozaj existuje. Inými slovami, je to pravdepodobnosť, že test odmietne nulovú 
#' hypotézu, ak je skutočne nepravdivá.
#' Dôležitosť sily testu:
  
#' Vyššia sila znamená väčšiu pravdepodobnosť odhalenia skutočného efektu.
#' Nízka sila môže viesť k tomu, že aj keď je efekt skutočný, test ho nezistí (tzv. 
#' chyba typu II).

#' Čo silu testu ovplyvňuje?
  
#' Veľkosť efektu: Väčší efekt je ľahšie odhaliť, takže sila je vyššia.
#' Veľkosť vzorky (n): Väčšia vzorka zvyšuje pravdepodobnosť odhalenia efektu.
#' Hladina významnosti (α): Vyššia hladina zvyšuje silu, ale zvyšuje aj riziko chyby
#' typu I (falošne pozitívny výsledok).
#' 
#' Príklad:Ak máme 90% šancu (sila 0,9) správne odhaliť rozdiel, ak naozaj existuje, 
#' znamená to, že máme 10% šancu, že ho nezistíme (chyba typu II).
#' 
#' 
#'# Nenormalne rozdelene data - spresnenie predchadzajuceho vypoctu pre 2. test
#'
#'1. Výpočet (neparametrickej) miery efektu 
#'Jednou z neparametrických mier efektu je rank-biserial correlation, 
#'ktorá sa dá vypočítať z Mann-Whitney U testu. 
#'Použijeme wilcox.test, ktorý vracia U-statistiku, z ktorej môžeme 
#'vypočítať efekt.




v1 <- c(48, 176, 185, 241, 300, 170)
v2 <- c(61, 185, 75, 72, 60, 82)

#' Wilcoxonov test
test_result <- wilcox.test(v1, v2, exact=FALSE)

#' Z-hodnota
z_value <- qnorm(test_result$p.value/2, lower.tail=FALSE)

#'Celkový počet pozorovaní
N <- length(v1) + length(v2)

#'Odhad efektu (rank-biserial correlation)
r <- z_value / sqrt(N)

#' Výpočet neparametrického Cohenovho d
d_np <- (2 * r) / sqrt(1 - r^2)

#' Výpis výsledkov
cat("Wilcoxonov test p-hodnota:", test_result$p.value, "\n")
cat("Hodnota Z:", z_value, "\n")
cat("Odhad efektu (rank-biserial correlation):", r, "\n")
cat("Neparametrické Cohenovo d:", d_np, "\n")


#' Odhad veľkosti vzorky pomocou pwr.t.test
result <- pwr.t.test(d = d_np, power=0.9, sig.level=0.05, type="two.sample", alternative="two.sided")
cat("Odhadovaná veľkosť na skupinu: ", ceiling(result$n))

#'Zhrnutie:
  
#'  Wilcoxonov test nenaznačuje štatisticky významný rozdiel medzi skupinami (p ≈ 0,15).
#' Ale odhad efektu je stredne veľký až veľký, čo znamená, že medzi skupinami 
#' je potenciálne významný rozdiel, ktorý je potrebné overiť na väčšej vzorke.
#' Veľkosť efektu (Cohenovo d) je približne 0,92, čo je veľký efekt 
#' podľa štandardných kritérií. Podľa tohto testu má prvá skupina vyssie 
#' hodnoty, ako druhá. Opät by to chcelo väčšiu vzorku.